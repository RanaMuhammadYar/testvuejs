<template>
    <div>
        <H2 class="text-center  mt-5">
        This is Vue page
        </H2>
    </div>
</template>

